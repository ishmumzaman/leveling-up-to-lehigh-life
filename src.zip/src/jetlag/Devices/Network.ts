import { Socket, io } from "socket.io-client";

/** The state of the network, which ties to if we have a user and a room */
enum NetworkState { Start, User, UserRoom }

/**
 * NetworkDevice interfaces with a server (see the "multiplayer-server" folder)
 * via socket.io to send and receive network events.
 */
export class NetworkDevice {
  /** A socket for communicating with the server */
  socket: Socket | undefined;

  /** The current state of the network stack */
  state: NetworkState = NetworkState.Start;

  /** An event handler for when the socket initially connects */
  evtConnected: () => void = () => { };

  /** An event handler for when the socket disconnects */
  evtDisconnected: (msg: string) => void = () => { };

  /** An event handler for when a remote user joins the room */
  evtUserJoined: (msg: string) => void = () => { };

  /** An event handler for when a remote user exits the room */
  evtUserLeft: (msg: string) => void = () => { };

  /** An event handler for when a remote user sends a message */
  broadcast: (msg: string) => void = () => { };

  /** An event handler for when a remote user changes their outfit */
  outfitChange: (msg: string) => void = () => { };

  /** An event handler for when a character moves */
  move: (msg: string) => void = () => { }

  /** An event handler for when we try to log in when we're already logged in */
  resErrHasUser: (msg: string) => void = () => { };

  /** An event handler for errors due to not logging in first */
  resErrNoUser: (msg: string) => void = () => { };

  /** An event handler for when the server says our username is taken */
  resErrUserTaken: (msg: string) => void = () => { };

  /** An event handler for when we request a room but already have one */
  resErrHasRoom: (msg: string) => void = () => { };

  /** An event handler for errors due to not having a room */
  resErrNoRoom: (msg: string) => void = () => { };

  /** An event handler for errors due to incorrectly formatted requests */
  resErrFormat: (msg: string) => void = () => { };

  /** An event handler for when a login request succeeds */
  resLoggedIn: (msg: string) => void = () => { };

  /** An event handler for when a logout request succeeds */
  resLoggedOut: (msg: string) => void = () => { };

  /** An event handler for when a broadcast is sent successfully */
  resSent: (msg: string) => void = () => { };

  /** An event handler for when we succeed in making a new room */
  resCreated: (msg: string) => void = () => { };

  /** An event handler for when we succeed in joining an existing room */
  resJoined: (msg: string) => void = () => { };

  /** An event handler for when we finish switching into a room */
  resSwitched: (msg: string) => void = () => {};

  /** An event handler for when we succeed in leaving a room */
  resLeft: (msg: string) => void = () => { };

  /**
   * Construct a NetworkDevice, for interacting with a remote server via
   * Socket.IO.  Note that by default, the network device is not connected to
   * anything.
   */
  constructor() { }

  /**
   * Connect to a server and start sending/receiving events
   *
   * @param serverAddress The address of the server to connect to
   */
  connect(serverAddress: string) {
    // Connect to the server
    this.socket = io(serverAddress);

    // Set up listeners for all event messages
    this.socket.on("EvtConnected", this.evtConnected);
    this.socket.on("EvtDisconnected", this.evtDisconnected);
    this.socket.on("EvtUserJoined", this.evtUserJoined);
    this.socket.on("EvtUserLeft", this.evtUserLeft);
    this.socket.on("Broadcast", this.broadcast);
    this.socket.on("OutfitChange", this.outfitChange)
    this.socket.on("Move", this.move)
    this.socket.on("ResErrHasUser", this.resErrHasUser);
    this.socket.on("ResErrNoUser", this.resErrNoUser);
    this.socket.on("ResErrUserTaken", this.resErrUserTaken);
    this.socket.on("ResErrHasRoom", this.resErrHasRoom);
    this.socket.on("ResErrNoRoom", this.resErrNoRoom);
    this.socket.on("ResErrFormat", this.resErrFormat);
    this.socket.on("ResLoggedIn", this.resLoggedIn);
    this.socket.on("ResLoggedOut", this.resLoggedOut);
    this.socket.on("ResSent", this.resSent);
    this.socket.on("ResCreated", this.resCreated);
    this.socket.on("ResJoined", this.resJoined);
    this.socket.on("ResSwitched", this.resSwitched);
    this.socket.on("ResLeft", this.resLeft);
    this.socket.on("connect", this.evtConnected);
    this.socket.on("disconnect", this.evtDisconnected);
    
  }

  /**
   * Send a message to the server to try to log in
   *
   * @param userId   The desired userId
   * @param userName The desired userName
   */
  doReqLoginToken(userId: string, userName: string) {
    this.socket?.emit("ReqLoginToken", JSON.stringify({ token: `${userId},${userName}` }))
  }

  /** Send a message to the server to try to create a new room */
  doReqCreate(builder: string) { this.socket?.emit("ReqCreate", JSON.stringify({builder: builder})); }

  /**
   * Send a message to the server to try to join an existing room
   *
   * @param roomId The Id of the room to join
   */
  doReqJoin(roomInfo: string) {
    this.socket?.emit("ReqJoin", JSON.stringify({ roomInfo }))
  }

  /** Send a request to the server to leave the room */
  doReqLeave(){ this.socket?.emit("ReqLeave", "") }

  /** Send a request to the server to switch to another builder's room or create one */
  doReqSwitch(name: string, playerLimit: number){this.socket?.emit("ReqSwitch", JSON.stringify({name: name, playerLimit: playerLimit}))}

  /** Send a request to the server to log out */
  doReqLogout() { this.socket?.emit("ReqLogout", ""); }

  /**
   * Broadcast a message to all other recipients in the room
   *
   * @param message The message to send
   */
  doBroadcast(message: string) { this.socket?.emit("Broadcast", message); }

  /**
   * Broadcast a message to all room recipients telling them you changed outfits
   * 
   * @param message The outfit change info
   */
  doOutfitChange(message: string) { this.socket?.emit("OutfitChange", message); }
  
  /**
   * Broadcast a message to all room recipients telling them you moved
   * 
   * @param message the move information
   */
  doMove(message: string) { this.socket?.emit("Move", message)}

  /** Forcibly disconnect from the server */
  doDisconnect() {
    this.socket?.disconnect();
    this.socket = undefined;
  }

  /**
   * Reset all of the event handlers.  This is a good thing to do after
   * disconnecting.
   */
  reset() {
    this.evtConnected = () => { };
    this.evtDisconnected = () => { };
    this.evtUserJoined = () => { };
    this.evtUserLeft = () => { };
    this.broadcast = () => { };
    this.outfitChange = () => { }
    this.move = () => { }
    this.resErrHasUser = () => { };
    this.resErrNoUser = () => { };
    this.resErrUserTaken = () => { };
    this.resErrHasRoom = () => { };
    this.resErrNoRoom = () => { };
    this.resErrFormat = () => { };
    this.resLoggedIn = () => { };
    this.resLoggedOut = () => { };
    this.resSent = () => { };
    this.resCreated = () => { };
    this.resJoined = () => { };
    this.resSwitched = () => { };
    this.resLeft = () => { };
  }
}