// Reviewed on 2024-09-27

/** An enum of all of the possible quests in the game */
export enum QuestNames {
    HawksQuest, FindRathBone, RoommateQuest
}