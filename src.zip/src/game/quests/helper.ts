/**
 * Quest Dialogue Helpers
 * ----------------------
 * This module provides utility functions to attach or retrieve quest-sensitive dialogue logic.
 * It supports dynamic switching of NPC dialogues based on quest status, such as:
 *
 * - Offering a quest if none is active and the current quest is not started
 * - Showing a fallback/busy message if another quest is already active
 * - Showing default dialogue if the quest is already active or completed
 */

import { DialogueDriver } from "../interactions/dialogue";
import { ConversationMap } from "../interactions/conversation";
import { QuestNames } from "./questNames";
import { Quest } from "./questLogic";
import { QuestStorage } from "../storage/questStorage";
import { SessionInfo } from "../storage/session";
import { stage } from "../../jetlag/Stage";
import { Places } from "../places/places";
import { Actor } from "../../jetlag";
import { NpcBehavior } from "../characters/NPC";

/**
 * Choose a dialogue path depending on the status of a given quest.
 *
 * @param options Configuration options:
 * - `questName`: The unique ID of the quest.
 * - `dialogues`: An object containing `prestart`, `completed`, and `busy` ConversationMaps.
 * - `prestartKey`: The key to start the pre-quest dialogue.
 * - `onAccept`: Optional callback if the user accepts the quest.
 * - `acceptFootprint`: The footprint number that triggers the `onAccept` callback (default is 99).
 *
 * @returns A DialogueDriver instance appropriate to the quest's current state.
 */
export function chooseQuestDialogueDriver(options: {
  questName: QuestNames,
  dialogues: {
    prestart: ConversationMap,
    completed: ConversationMap,
    busy: ConversationMap,
  },
  prestartKey: string,
  onAccept?: () => void,
  acceptFootprint?: number,
}): DialogueDriver {
  const status = QuestStorage.getStatus(options.questName);
  const activeQuest = QuestStorage.getActiveQuest();
  const acceptKey = options.acceptFootprint ?? 99;

  if ((status === "Not Active" || status === "Paused") && activeQuest === undefined) {
    return new DialogueDriver(options.dialogues.prestart, options.prestartKey, (footprints) => {
      if (footprints.has(acceptKey) && options.onAccept) {
        options.onAccept();
      }
    });
  }

  if (activeQuest && activeQuest !== options.questName) {
    return new DialogueDriver(options.dialogues.busy, "start");
  }


  return new DialogueDriver(options.dialogues.completed, "start");
}

/**
 * Quickly wires up an NPC to start a quest using dialogue.
 *
 * @param options Configuration options:
 * - `npc`: The character to attach the logic to.
 * - `quest`: The Quest instance.
 * - `prestartDialogue`: The dialogue shown before quest starts.
 * - `busyDialogue`: Dialogue if another quest is active.
 * - `defaultDialogue`: Dialogue shown once the quest is active.
 * - `levelNumber`: The level's ID/number.
 * - `place`: The Place enum value the NPC is in.
 * - `acceptFootprint`: (optional) the footprint that triggers quest start.
 * - `otherNPCs`: (optional) Array of other NPCs to run `onMakeNpc` for before quest starts.
 */
export function makeQuestStartingNpc(options: {
  npc: Actor,
  quest: Quest,
  prestartDialogue: ConversationMap,
  busyDialogue: ConversationMap,
  completeDialogue: ConversationMap,
  levelNumber: number,
  place: Places,
  acceptFootprint?: number,
  otherNPCs?: Actor[],
}) {
  const npcBehavior = options.npc.extra as NpcBehavior;
  const questName   = options.quest.questName as QuestNames;

  // The “offer quest” logic
  const offerQuest = () => {
    const driver = chooseQuestDialogueDriver({
      questName,
      dialogues: {
        prestart: options.prestartDialogue,
        busy:     options.busyDialogue,
        completed:  options.completeDialogue,
      },
      prestartKey: "start",
      acceptFootprint: options.acceptFootprint,
      onAccept:        () => {
        const s = stage.storage.getSession("sStore") as SessionInfo;
        s.currQuest = options.quest;
        // spawn NPCs & start quest…
        for (const npc of options.otherNPCs ?? []) {
          options.quest.onMakeNpc(options.place, options.levelNumber, npc);
        }
        options.quest.start();
        options.quest.onBuildPlace(options.place, options.levelNumber);
        options.quest.onMakeNpc(options.place, options.levelNumber, options.npc);
      },
    });
    npcBehavior.setNextDialogue(driver);
    npcBehavior.nextDialogue();
  };

  // Wrap onInteract so that *once* the quest is active we delete ourselves
  npcBehavior.onInteract = () => {
    const status = QuestStorage.getStatus(questName);

    if (status === "Active") {
      // 1) Remove our custom handler so the Spawner callback falls back to nextDialogue()
      delete npcBehavior.onInteract;
      // 2) Trigger the queued-up step-dialogue
      npcBehavior.nextDialogue();
    } else {
      // Still offering/prestart or busy: run the helper logic
      offerQuest();
    }
  };
}