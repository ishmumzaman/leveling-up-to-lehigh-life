/** All of the places / builders of the game */
export enum Places {
    ASA_CAMPUS_OUTSIDE,
    MM_DORM,
    MM_HALL,
    MM_STAIRS,
    HAWKS_NEST,
    RATHBONE,
    THE_VOID
}